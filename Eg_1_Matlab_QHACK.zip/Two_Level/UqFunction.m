function [UqFunction] = UqFunction(theta)
%%
%{
    Generate the ancillary state |a>
%}
%%
%   Pauli operators
I=[1 0;0 1];X=[0 1;1 0];Y=[0 -sqrt(-1);sqrt(-1) 0];Z=[1 0;0 -1];Hadamard=[1,1;1,-1]/sqrt(2);
%   Qubit states
zero=[1;0];one=[0;1];
%%
%   Set parameters
delta=1;Omega=1;gamma=1;
Delta_t=0.01;
%%
%	Exact vector a
alpha=sqrt(2)/2*delta*Delta_t;
beta=(1-gamma*Delta_t/2);
%%
%   The non-Hermitian operator H
H0=kron(I,sqrt(-1)*Hadamard);H1=kron(I,-Z);
H2=kron((-sqrt(-1)*alpha*Hadamard+beta*I)/(sqrt(alpha^2+beta^2)),I);
H3=kron(-Z,I);H4=kron(X,X);H5=kron(X,-sqrt(-1)*Y);H6=kron(-sqrt(-1)*Y,X);H7=kron(-Y,Y);

%   The non-Hermitian operator Q=I+Delta_t*H
Q0=H0;Q1=H1;Q2=H2;Q3=H3;Q4=H4;Q5=H5;Q6=H6;Q7=H7;
%%
%   Multi-controlled unitary
Lambda_Q=blkdiag(Q0,Q1,Q2,Q3,Q4,Q5,Q6,Q7);

UqFunction=abs(1-1/(32^2)*(trace((Uq(theta)')*Lambda_Q))^2);
end