function [UqLay] = UqLay(theta)
%%
%   The number of parameters 20
%%
%   Pauli operators
I=[1 0;0 1];X=[0 1;1 0];Y=[0 -sqrt(-1);sqrt(-1) 0];Z=[1 0;0 -1];
%   Qubit states
zero=[1;0];one=[0;1];
%%
%   Parameterized circuit
%%
%   Layer L=1
L1_1=expm(-sqrt(-1)*theta(1)/2*Z)*expm(-sqrt(-1)*theta(6)/2*Y)*expm(-sqrt(-1)*theta(11)/2*Z);
L1_2=expm(-sqrt(-1)*theta(2)/2*Z)*expm(-sqrt(-1)*theta(7)/2*Y)*expm(-sqrt(-1)*theta(12)/2*Z);
L1_3=expm(-sqrt(-1)*theta(3)/2*Z)*expm(-sqrt(-1)*theta(8)/2*Y)*expm(-sqrt(-1)*theta(13)/2*Z);
L1_4=expm(-sqrt(-1)*theta(4)/2*Z)*expm(-sqrt(-1)*theta(9)/2*Y)*expm(-sqrt(-1)*theta(14)/2*Z);
L1_5=expm(-sqrt(-1)*theta(5)/2*Z)*expm(-sqrt(-1)*theta(10)/2*Y)*expm(-sqrt(-1)*theta(15)/2*Z);

L1=kron(L1_1,kron(L1_2,kron(L1_3,kron(L1_4,L1_5))));

%   Entangled circuit
Ent_L1_1=kron(zero*zero',I)+kron(one*one',expm(-sqrt(-1)*theta(16)/2*Y));
Ent_L1_2=kron(zero*zero',I)+kron(one*one',expm(-sqrt(-1)*theta(17)/2*Y));
Ent_L1_3=kron(zero*zero',I)+kron(one*one',expm(-sqrt(-1)*theta(18)/2*Y));
Ent_L1_4=kron(zero*zero',I)+kron(one*one',expm(-sqrt(-1)*theta(19)/2*Y));
Ent_L1_5=kron(I,kron(I,kron(I,kron(I,zero*zero'))))+kron(expm(-sqrt(-1)*theta(20)/2*Y),kron(I,kron(I,kron(I,one*one'))));

Ent_L1=Ent_L1_5*kron(I,kron(Ent_L1_3,Ent_L1_4))*kron(Ent_L1_1,kron(Ent_L1_2,I));

L_1=Ent_L1*L1;

%%
UqLay=L_1;
end