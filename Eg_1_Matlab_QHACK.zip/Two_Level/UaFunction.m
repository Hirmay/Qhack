function [UaFunction] = UaFunction(theta)
%%
%{
    Generate the ancillary state |a>
%}
%%
%   Pauli operators
I=[1 0;0 1];X=[0 1;1 0];Y=[0 -sqrt(-1);sqrt(-1) 0];Z=[1 0;0 -1];Hadamard=[1,1;1,-1]/sqrt(2);
%   Qubit states
zero=[1;0];one=[0;1];
%%
%   Set parameters
delta=1;Omega=1;gamma=1;
Delta_t=0.01;
%%
%	Exact vector a
alpha=sqrt(2)/2*delta*Delta_t;
beta=(1-gamma*Delta_t/2);
aa=[Delta_t*sqrt(2)/2*delta;Delta_t*gamma/4;sqrt(alpha^2+beta^2);Delta_t*gamma/4;Delta_t*gamma/4;Delta_t*gamma/4;Delta_t*gamma/4;Delta_t*gamma/4];
a=sqrt(aa);a=a/norm(a);

%   Training the parameterized quantum circuit Ua(theta)
IniState=kron(zero,kron(zero,zero));
Appro_a=Ua(theta)*IniState
%   Witness the training performance
Error_a=((a')*Appro_a)^2

%   Define the cost function
F1=(a(1)^2)*log2((Appro_a(1)^2)/(a(1)^2))+(a(2)^2)*log2((Appro_a(2)^2)/(a(2)^2))+(a(3)^2)*log2((Appro_a(3)^2)/(a(3)^2));
F2=(a(4)^2)*log2((Appro_a(4)^2)/(a(4)^2))+(a(5)^2)*log2((Appro_a(5)^2)/(a(5)^2))+(a(6)^2)*log2((Appro_a(6)^2)/(a(6)^2));
F3=(a(7)^2)*log2((Appro_a(7)^2)/(a(7)^2))+(a(8)^2)*log2((Appro_a(8)^2)/(a(8)^2));

%   Prepare the Bell state
%�Ʊ�8ά��ȫ1����
Bell_State=ones(8,1)/norm(ones(8,1));
%   The sum of vector a
Sum_a=sum(a);

UaFunction=abs(Sum_a-norm(ones(8,1))*Bell_State'*Appro_a)-(F1+F2+F3);
end