function [UaLay] = UaLay(theta)
%%
%   The number of parameters 5*L
%%
%   Pauli operators
I=[1 0;0 1];X=[0 1;1 0];Y=[0 -sqrt(-1);sqrt(-1) 0];Z=[1 0;0 -1];
%   Qubit states
zero=[1;0];one=[0;1];
%%
%   Parameterized circuit
%   Layer L=1
L1_1=expm(-sqrt(-1)*theta(1)/2*Y);
L1_2=expm(-sqrt(-1)*theta(2)/2*Y);
L1_3=expm(-sqrt(-1)*theta(3)/2*Y);

L1=kron(L1_1,kron(L1_2,L1_3));

%   Entangled circuit
Ent_L1_1=kron(zero*zero',I)+kron(one*one',Z);
Ent_L1_2=kron(zero*zero',I)+kron(one*one',Z);
Ent_L1_3=kron(I,kron(I,zero*zero'))+kron(Z,kron(I,one*one'));

Ent_L1=Ent_L1_3*kron(I,Ent_L1_2)*kron(Ent_L1_1,I);

L_1=Ent_L1*L1;

UaLay=L_1;
end