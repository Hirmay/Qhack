function [Uq] = Uq(theta)
%%
%subfigure C
Uq1=UqLay(theta(81:100))*UqLay(theta(61:80))*UqLay(theta(41:60))*UqLay(theta(21:40))*UqLay(theta(1:20));
Uq2=UqLay(theta(181:200))*UqLay(theta(161:180))*UqLay(theta(141:160))*UqLay(theta(121:140))*UqLay(theta(101:120));
Uq3=UqLay(theta(281:300))*UqLay(theta(261:280))*UqLay(theta(241:260))*UqLay(theta(221:240))*UqLay(theta(201:220));
Uq4=UqLay(theta(381:400))*UqLay(theta(361:380))*UqLay(theta(341:360))*UqLay(theta(321:340))*UqLay(theta(301:320));

Uq=Uq4*Uq3*Uq2*Uq1;

%subfigure D
% Uq1=UqLay(theta(81:100))*UqLay(theta(61:80))*UqLay(theta(41:60))*UqLay(theta(21:40))*UqLay(theta(1:20));
% Uq2=UqLay(theta(181:200))*UqLay(theta(161:180))*UqLay(theta(141:160))*UqLay(theta(121:140))*UqLay(theta(101:120));
% 
% Uq=Uq2*Uq1;

end