function [Ua] = Ua(theta)
%%
Ua=UaLay(theta(10:12))*UaLay(theta(7:9))*UaLay(theta(4:6))*UaLay(theta(1:3));
end